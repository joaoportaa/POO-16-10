<?php

class Aluno{

    private $RM;

    public function getRM(): string{
        return = $this->$RM;
    }
}
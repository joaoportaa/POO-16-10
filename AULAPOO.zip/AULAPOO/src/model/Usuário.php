<?php

class Usuário{

    private $NomeUsuario;

     public function getNomeUsuario(): string {
        return = $this->$NomeUsuario;
    }
}
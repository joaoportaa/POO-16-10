<?php 

class Curso{

    private $NomeCurso;

    public function getNomeCurso(): string{
        return = $this->$NomeCurso;
    }
}
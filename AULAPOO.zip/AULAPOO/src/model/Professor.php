<?php

class Professor{
    
    private $RF;

    public function getRF(): string{
        return = $this->$RF;
    }
}
<?php

class Funcionario{
    private $Cargo

    public function getCargo(): string{
        return = $this->$Cargo;
    }
}
<?php

class Matricula{

    public function __construct(Aluno $RM, Professor $RF, Funcionário $Cargo){
    $this->RM = $RM;
    $this->RF = $RF;
    $this->Cargo = $Cargo;
    }



}
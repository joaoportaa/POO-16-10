<?php

class Aluno{

    private $RM;

    public function getRm(): string{
        return $this->RM;
    }
}
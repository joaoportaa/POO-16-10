<?php

class Usuario{
    public $NomeUsuario;
    public $idUsuario;
    public $emailUsuario;
    public $senhaUsuario;

    function __constructor($Usuario){
        $this->NomeUsuario = $NomeUsuario;
        $this->idUsuario = $Usuario;
        $this->emailUsuario = $emailUsuario;
        $this->senhaUsuario = $senhaUsuario;
    }
}
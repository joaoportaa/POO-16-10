<?php

$nomeAluno = $_GET['Roberto'];

echo $nomeAluno;
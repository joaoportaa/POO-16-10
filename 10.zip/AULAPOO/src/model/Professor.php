<?php

class Professor{
    
    private $RF;

    public function getRf(): string{
        return $this->RF;
    }
}
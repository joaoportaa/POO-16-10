<?php 

class Curso{

    private $NomeCurso;

    public function getNomeDoCurso(): string{
        return $this->NomeCurso;
    }
}
<?php

class Pessoa{
    public $NomePessoa;

    function __constructor($NomePessoa){
        $this->NomePessoa = $NomePessoa;

    }
}
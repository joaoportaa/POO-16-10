<?php

class Usuário{

    private $NomeUsuario;

     public function getNomeDeUsuario(): string {
        return $this->NomeUsuario;
    }
}
<?php

class Funcionario{
    private $Cargo;

    public function getCARGO(): string{
        return $this->Cargo;
    }
}